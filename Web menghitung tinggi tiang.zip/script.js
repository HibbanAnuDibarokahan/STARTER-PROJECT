const $ = (s) => document.querySelector(s);

    function hitungtinggi (
      panjang_bayangan_tiang,
      panjang_bayangan_tongkat,
      tinggi_tongkat = 1.6
    )
    {
    // Mengambil nilai angka dari inputan HTML
  panjang_bayangan_tiang= Number(document.getElementById('bayanganTiang').value);
 panjang_bayangan_tongkat = Number(document.getElementById('bayanganTongkat').value);
tinggi_tongkat = Number(document.getElementById('tinggiTongkat').value);

  let tinggi_tiang = (panjang_bayangan_tiang * tinggi_tongkat) / panjang_bayangan_tongkat

    // Menampilkan hasil langsung ke kotak hasil di web
    let kotakHasil = document.getElementById('hasilOutput');
    kotakHasil.innerHTML = `Tinggi tiang adalah ${tinggi_tiang} meter! 🚀`;
}

